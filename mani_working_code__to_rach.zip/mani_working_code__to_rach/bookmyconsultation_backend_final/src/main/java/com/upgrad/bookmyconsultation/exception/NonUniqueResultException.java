package com.upgrad.bookmyconsultation.exception;

public class NonUniqueResultException extends RuntimeException {

}
