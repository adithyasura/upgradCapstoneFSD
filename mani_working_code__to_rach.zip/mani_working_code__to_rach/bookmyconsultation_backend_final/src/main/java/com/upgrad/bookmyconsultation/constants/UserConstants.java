package com.upgrad.bookmyconsultation.constants;

public interface UserConstants {

    String INVALID_INPUT_ERROR_CODE="ERR_INVALID_INPUT";
    String INVALID_INPUT_ERROR_MSG="Invalid input. Parameter name: ";
}
